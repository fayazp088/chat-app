import React from 'react';
import './InfoBar.css';

import leave from '../../icons/closeIcon.png';
import join from '../../icons/onlineIcon.png';

const InfoBar = ({room}) => {
  return (
    <div className="infoBar">
      <div className="leftInnerContainer">
        <img className="onlineIcon"
          src={join} alt="get online" />
        <h3>{room}</h3>
      </div>
      <div className="rightInnerContainer">
        <a href="/">
          <img src={leave} alt="close"/>
        </a>
      </div>
    </div>
  )
}

export default InfoBar;
